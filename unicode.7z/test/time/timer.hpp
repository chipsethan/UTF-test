#ifndef TIMER_HPP_
#define TIMER_HPP_

#include <iostream>

#if (defined _WIN64) || (defined _WIN32)
#include <windows.h>
#elif (defined __unix__)
#include <time.h>
#else
#if !defined (__cplusplus) || (__cplusplus < 201103)
#include <ctime>
#else
#include <chrono>
#endif
#endif

namespace Example
{

#if (defined _WIN64) || (defined _WIN32)

class timer
{
public:
  timer();
  void start();
  void stop();
  double duration() const;
  operator double() const;
  friend std::ostream& operator << (std::ostream&, const timer&);

private:
  LARGE_INTEGER m_begin;
  LARGE_INTEGER m_end;
  static LARGE_INTEGER fr;
  static double frequency();
};

#elif (defined __unix__)


class timer
{
public:
  timer();
  void start();
  void stop();
  double duration() const;
  operator double() const;
  friend std::ostream& operator << (std::ostream&, const timer&);

private:
  struct timespec m_begin;
  struct timespec m_end;
};

#else

class timer
{
public:
  timer();
  void start();
  void stop();
  double duration() const;
  operator double() const;
  friend std::ostream& operator << (std::ostream&, const timer&);

private:
#if !defined (__cplusplus) || (__cplusplus < 201103)
  std::clock_t m_begin;
  std::clock_t m_end;
#else
  std::chrono::time_point<std::chrono::high_resolution_clock> m_begin;
  std::chrono::time_point<std::chrono::high_resolution_clock> m_end;
#endif
};

#endif

}

#endif // TIMER_HPP_
