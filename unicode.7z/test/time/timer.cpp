
#include "timer.hpp"

namespace Example
{

#if (defined _WIN64) || (defined _WIN32)

timer::timer()
{
}

void timer::start()
{
  QueryPerformanceCounter(&m_begin);
}

void timer::stop()
{
  QueryPerformanceCounter(&m_end);
}

double timer::duration() const
{
  return (m_end.QuadPart - m_begin.QuadPart) * 1000.0 / frequency();
}

timer::operator double () const
{
  return duration();
}

std::ostream& operator << (std::ostream& os, const timer& t)
{
  os << t.duration();
  return os;
}

double timer::frequency()
{
  QueryPerformanceFrequency(&fr);
  return double(fr.QuadPart);
}

LARGE_INTEGER timer::fr;

#elif (defined __unix__)


timer::timer()
{
}

void timer::start()
{
  clock_gettime(CLOCK_MONOTONIC, &m_begin);
}

void timer::stop()
{
  clock_gettime(CLOCK_MONOTONIC, &m_end);
}

double timer::duration() const
{
  struct timespec ts;
  ts.tv_sec = m_end.tv_sec - m_begin.tv_sec;
  ts.tv_nsec = m_end.tv_nsec - m_begin.tv_nsec;
  return ts.tv_sec * 1000.0 + ts.tv_nsec / 1000000.0;
}

timer::operator double() const
{
  return duration();
}

std::ostream& operator << (std::ostream& os, const timer& t)
{
  os << t.duration();
  return os;
}

#else

timer::timer()
{
}

void timer::start()
{
#if !defined (__cplusplus) || (__cplusplus < 201103)
  m_begin = std::clock();
#else
  m_begin = std::chrono::high_resolution_clock::now();
#endif
}

void timer::stop()
{
#if !defined (__cplusplus) || (__cplusplus < 201103)
  m_end = std::clock();
#else
  m_end = std::chrono::high_resolution_clock::now();
#endif
}

double timer::duration() const
{
  double d = 0.0;
#if !defined (__cplusplus) || (__cplusplus < 201103)
  d = m_end - m_begin;
#else
  std::chrono::duration<double> diff = m_end- m_begin;
  d = diff.count() * 1000.0;
#endif
  return d;
}

timer::operator double() const
{
  return duration();
}

std::ostream& operator << (std::ostream& os, const timer& t)
{
  os << t.duration();
  return os;
}

#endif

}
