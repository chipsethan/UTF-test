
#include <fstream>
#include <iostream>

#include "unicodeA/utf8.h"
#include "unicodeB/utf8.h"
#include "test/time/timer.hpp"

int main()
{
  std::string str;
  std::ifstream fin("test/case/case.txt");
  if(!fin)
    return 1;
  std::streambuf * pbuf = fin.rdbuf();
  do
  {
    const char ch = pbuf->sgetc();
    str += ch;
  } while(pbuf->snextc() != EOF);
  fin.close();
  Example::timer t;
  std::cout << "Mikhail Pilin (2.3)\n";
  t.start();
  std::u32string au321 = UTF::to_utf32(str);
  t.stop();
  std::cout << "UTF8-->UTF32:" << t.duration() << "ms\n";
  t.start();
  std::u16string au161 = UTF::to_utf16(str);
  t.stop();
  std::cout << "UTF8-->UTF16:" << t.duration() << "ms\n";
  t.start();
  std::string au81 = UTF::to_utf8(au321);
  t.stop();
  std::cout << "UTF32-->UTF8:" << t.duration() << "ms\n";
  t.start();
  std::string au82 = UTF::to_utf8(au161);
  t.stop();
  std::cout << "UTF16-->UTF8:" << t.duration() << "ms\n";

  std::cout << "Nemanja Trifunovic (3.2.1)\n";
  t.start();
  std::u32string bu321 = UTF::utf8to32(str);
  t.stop();
  std::cout << "UTF8-->UTF32:" << t.duration() << "ms\n";
  t.start();
  std::u16string bu161 = UTF::utf8to16(str);
  t.stop();
  std::cout << "UTF8-->UTF16:" << t.duration() << "ms\n";
  t.start();
  std::string bu81 = UTF::utf32to8(bu321);
  t.stop();
  std::cout << "UTF32-->UTF8:" << t.duration() << "ms\n";
  t.start();
  std::string bu82 = UTF::utf16to8(bu161);
  t.stop();
  std::cout << "UTF16-->UTF8:" << t.duration() << "ms\n";

  if(au321 == bu321 && au161 == bu161 && au81 == bu81 && au82 == bu82)
    std::cout << "identical results, ok\n";
}
